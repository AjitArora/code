# vehicle types
CAR = 0x01