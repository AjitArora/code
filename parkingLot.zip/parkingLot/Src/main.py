import sys
from inputParser import inputParser

inputParser().run(sys.argv)